#include <avr/io.h>
#include <avr/wdt.h>
#include <util/delay.h>

void InitPWM() {
	DDRB = (1 << PB1) | (1 << PB2) | (1 << PB3);
	TCCR1A = (1 << COM1A1) | (1 << COM1B1) | (1 << WGM10);
	TCCR1B = (1 << CS10);
	TCCR2 = (1 << CS20) | (1 << WGM20) | (1 << COM21);
}

uint8_t LinearizeForEye(uint8_t x) {
	//	if (x >= 0 && x < 5) {
	return (x);
	//	} else if (x >= 5 && x < 50) {
	//		return (x / 5);
	//	}
	//	return (((uint16_t) x) * x) >> 8;
}

char g_cPWMr = 0;
char g_cPWMg = 0;
char g_cPWMb = 0;

void SetColor(uint8_t uiR, uint8_t uiG, uint8_t uiB) {
	g_cPWMr = LinearizeForEye(uiR);
	g_cPWMg = LinearizeForEye(uiG) >> 1;
	g_cPWMb = LinearizeForEye(uiB) >> 1;
	OCR1BL = g_cPWMr;
	OCR1AL = g_cPWMg;
	OCR2 = g_cPWMb;
}

int main() {
	InitPWM();
	SetColor(0xff, 0xff, 0x7f);
//	DDRB |= (1 << PB1) | (1 << PB2) | (1 << PB3);

	ADMUX |= (1<< REFS1) | (1 << REFS0) | (1 << ADLAR);
	ADCSRA |= (1<< ADEN) | (1<<ADFR);
	ADCSRA |= (1<<ADSC);

	while (1) {
//		PORTB = (1 << PB1) | (1 << PB2) | (1 << PB3);
//		_delay_ms(510);
//		wdt_reset();
//		PORTB = 0;
		SetColor(ADCH, 0xff, 0xff);
		_delay_ms(10);
		wdt_reset();
	}
}
